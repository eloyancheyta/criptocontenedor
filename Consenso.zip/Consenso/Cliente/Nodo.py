class Nodo:
    def __init__(self):
        self.IP = "127.0.0.1"
        self.puerto = -1

    @property
    def get_ip(self):
        return self.IP

    @property
    def get_puerto(self):
        return self.puerto

    @property
    def set_ip(self, ip):
        self.IP = ip

    @property
    def set_puerto(self, puerto):
        self.puerto = puerto