import socket
import json
import struct
from Request import Request
from Response import Response

class ClienteSocketCC:
    def __init__(self, ip, puerto):
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((ip, puerto))
            self.buffered_input_stream = self.socket.makefile("rb")
            self.buffered_output_stream = self.socket.makefile("wb")
            self.gson = json.JSONEncoder()
        except Exception as ex:
            print(f"Error al conectar el socket: {ex}")
            self.cerrar_socket()

    def send_request(self, request):
        request = request.to_dict()
        data = self.gson.encode(request).encode("ISO-8859-1")
        self.send_data(data)

    def send_message_str(self, message_str):
        data = message_str.encode("ISO-8859-1")
        self.send_data(data)

    def send_metadata(self, message_bytes):
        length_bytes = struct.pack(">H", len(message_bytes))
        self.buffered_output_stream.write(length_bytes)
        self.buffered_output_stream.write(message_bytes)
        self.buffered_output_stream.flush()

    def receive_response(self):
        data = self.receive_data()        
        response = json.JSONDecoder().decode(data.decode("ISO-8859-1"))
        response = Response.from_dict(response)
        return response

    def receive_message_str(self):
        data = self.receive_data()
        return data.decode("ISO-8859-1")

    def receive_metadata(self):
        length_bytes = self.buffered_input_stream.read(2)
        length = struct.unpack(">H", length_bytes)[0]
        message_bytes = self.buffered_input_stream.read(length)
        return message_bytes

    def send_data(self, data):
        data_length = len(data)
        data_length_bytes = struct.pack(">Q", data_length)
        self.buffered_output_stream.write(data_length_bytes)
        self.buffered_output_stream.write(data)
        self.buffered_output_stream.flush()

    def receive_data(self):
        data_length_bytes = self.buffered_input_stream.read(8)
        data_length = struct.unpack(">Q", data_length_bytes)[0]
        received_data = b""
        while data_length > 0:
            buffer_size = min(8192, data_length)
            buffer = self.buffered_input_stream.read(buffer_size)
            received_data += buffer
            data_length -= len(buffer)
        return received_data

    def cerrar_socket(self):
        try:
            if self.buffered_input_stream:
                self.buffered_input_stream.close()
            if self.buffered_output_stream:
                self.buffered_output_stream.close()
            if self.socket and self.socket.fileno() != -1:
                self.socket.close()
            #print("Socket cerrado exitosamente")
        except Exception as ex:
            print(f"Error al cerrar el socket: {ex}")