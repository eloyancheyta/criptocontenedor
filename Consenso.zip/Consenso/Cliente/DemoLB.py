import threading
import time
import json
import base64
import struct

# Importar las clases desde sus módulos respectivos
from Nodo import Nodo
from Request import Request
from Response import Response
from ClienteSocketCC import ClienteSocketCC

class ClienteConsenso:
    count_a = 0
    count_b = 0
    count_c = 0
    lock = threading.Lock()

    def main(self):
        host = "192.168.100.4"  # "localhost"
        port = 5000
        times = 1000

        ind_replica = 0
        request_list = []

        for i in range(times):
            if ind_replica == 3:
                ind_replica = 0

            n = ind_replica
            index = i

            # Usar el nombre de la clase, no el del módulo, al crear instancias
            thread = threading.Thread(target=lambda: self.get_worker(host, port + n, index))
            request_list.append(thread)
            thread.start()
            ind_replica += 1

        for thread in request_list:
            thread.join()

        print("\nBalance de carga:"
              + "\nréplica 1 (5000): " + str(self.count_a)
              + "\nréplica 2 (5001): " + str(self.count_b)
              + "\nréplica 3 (5002): " + str(self.count_c))

    def get_worker(self, host, port, index):
        worker = None
        codigo = -1
        tiempo_espera = 0.01
        number_max_retries = 3
        num_intentos = 0
        req = Request()
        req.cuerpo_put("tipo", "getWorker")
        gson = json.JSONEncoder()
        #req = req.to_dict()

        while codigo != 200 and num_intentos < number_max_retries:
            num_intentos += 1
            cscc = self.create_socket_client(host, port)

            try:
                cscc.send_request(req)
                res = cscc.receive_response()
                cscc.cerrar_socket()
                #res = Response.from_dict(res)
                #print("response: ", res.get_encabezado(), res.get_cuerpo())
                res.print_response()
                
                codigo = int(res.encabezado_get("codigo"))
                #print("codigo: ", codigo)

                if codigo == 200:
                    worker_json_base64 = res.cuerpo_get("worker")
                    #print("worker (worker_json_base64): ",res.cuerpo_get("worker"))
                    worker_bytes = base64.b64decode(worker_json_base64) #.decode("ISO-8859-1")
                    #print("worker (worker_bytes): ",worker_bytes)
                    worker_json = worker_bytes.decode("ISO-8859-1")
                    #print("worker (worker_json): ",worker_json)
                    worker_dict = json.JSONDecoder().decode(worker_json)
                    #print("worker (worker_dict): ",worker_dict)
                    #worker = Nodo.from_dict(worker_dict)
                    #worker = json.JSONDecoder().decode(worker_json, Nodo)
                    #print("worker puerto: ",Nodo.get_puerto())
                    #
                    puerto = worker_dict["puerto"]
                    #print("worker puerto: ",puerto)                    
                    self.statistics(puerto)
                    #self.statistics(worker_dict)
                    num_intentos = number_max_retries
                    break;
                    

            except Exception as ex:
                print(f"Error: {ex}")

            time.sleep(tiempo_espera)
            print("esperando")

    @classmethod
    def statistics(cls, puerto):
        #with cls.__dict__["__lock__"]:
        with cls.lock:
            #puerto = worker_dict["puerto"]
            if puerto == 55000:
                cls.count_a += 1
            elif puerto == 55001:
                cls.count_b += 1
            elif puerto == 55002:
                cls.count_c += 1

    def create_socket_client(self, host, port):
        try:
            cscc = ClienteSocketCC(host, port)
            return cscc
        except Exception as ex:
            print(f"Error: {ex}")
            return None                

if __name__ == "__main__":
    ClienteConsenso().main()
