import time

class Response:
    def __init__(self):
        self.encabezado = {"timestamp": int(time.time()) * 1000}
        self.cuerpo = {}

    def get_encabezado(self):
        return self.encabezado

    def set_encabezado(self, encabezado):
        self.encabezado = encabezado

    def encabezado_put(self, clave, valor):
        self.encabezado[clave] = valor
        return self.encabezado[clave]
        #return self.encabezado.put(clave, valor)

    def encabezado_get(self, clave):
        return self.encabezado[clave]
        #return self.encabezado.get(clave)

    def get_cuerpo(self):
        return self.cuerpo

    def set_cuerpo(self, cuerpo):
        self.cuerpo = cuerpo

    def cuerpo_put(self, clave, valor):
        self.cuerpo[clave] = valor
        return self.cuerpo[clave]
        #return self.cuerpo.put(clave, valor)

    def cuerpo_get(self, clave):
        return self.cuerpo[clave]
        #return self.cuerpo.get(clave)

    def print_response(self):
        head = ""
        for clave, valor in self.encabezado.items():
            head += f"Clave: {clave}, Valor: {valor}\n"

        body = ""
        for clave, valor in self.cuerpo.items():
            body += f"Clave: {clave}, Valor: {valor}\n"

        print(f"Response\nEncabezado:\n{head}Cuerpo:\n{body}")

    def print_response_with_msg(self, msg):
        head = ""
        for clave, valor in self.encabezado.items():
            head += f"Clave: {clave}, Valor: {valor}\n"

        body = ""
        for clave, valor in self.cuerpo.items():
            body += f"Clave: {clave}, Valor: {valor}\n"

        print(f"{msg}\nResponse\nEncabezado:\n{head}Cuerpo:\n{body}")

    def to_string(self, msg, tipo_request_o_response):
        obj = f"{tipo_request_o_response}\nEncabezado:\n"
        for clave, valor in self.encabezado.items():
            obj += f"Clave: {clave}, Valor: {valor}\n"

        obj += "Cuerpo:\n"
        for clave, valor in self.cuerpo.items():
            obj += f"Clave: {clave}, Valor: {valor}\n"

        return f"{obj}{msg}\n"

    def to_dict(self):
        return {"encabezado": self.encabezado, "cuerpo": self.cuerpo}

    @classmethod
    def from_dict(cls, data):
        obj = cls()
        obj.encabezado = data.get("encabezado", {})
        obj.cuerpo = data.get("cuerpo", {})
        return obj    