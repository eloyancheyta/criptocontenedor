package app;

import com.google.gson.Gson;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author eloy_
 */
public class APIIntraCC extends Thread {

    Socket clientSocket;
    BufferedInputStream bufferedInputStream;
    BufferedOutputStream bufferedOutputStream;
    Gson gson;
    Response response;
    Request request;
    //long time = System.currentTimeMillis();

    public APIIntraCC(Socket clientSocket) {
        try {
            //System.out.println("nueva conexión : " + time);
            this.clientSocket = clientSocket;
            bufferedInputStream = new BufferedInputStream(clientSocket.getInputStream());
            bufferedOutputStream = new BufferedOutputStream(clientSocket.getOutputStream());
            gson = new Gson();
        } catch (IOException ex) {
            Logger.getLogger(APIIntraCC.class.getName()).log(Level.SEVERE, null, ex);
            cerrarSocket();
        }
    }

    public void run() {
        try {
            response = new Response();
            try {
                response.encabezadoPut("codigo", 200);
                response.encabezadoPut("mensaje", "");
                request = receiveRequest();
                Logger.getLogger(APIIntraCC.class.getName()).log(Level.INFO, request.toString("", "Request"));

                String datos = "";

                
                // ejecutar un subproceso con una app .py o .jar
                // asume que los resultados de all que vayas a ejecutar se encuentrar en un dir
                
                
                // leer carpeta
                //leer el archivo
                
                //json de respuesta {}
                // formatear la respuesta}
                //crear objeto de respuesta
                
                //sendResponse(response);

                
                switch ((String) request.getCuerpo().get("op")) {
                    //switch ((String) request.getCuerpo().get("tipo")) {

                    case "toLowerCase":

                        datos = (String) request.cuerpoGet("datos");
                        String datosToLowerCase = datos.toLowerCase();

                        //hacer una petición hacia adelante al servicio to upper case en un hilo
                        String id = (String) request.cuerpoGet("id");
                        String datosToUpperCase = toUpperCase(id, datosToLowerCase);
                        //System.out.println("in datosToUpperCase: " + datosToUpperCase);

                        //responders
                        response.cuerpoPut("datosToLowerCase", datosToLowerCase);
                        response.cuerpoPut("datosToUpperCase", datosToUpperCase);
                        // responseIntraCC.cuerpoPut("datosToUpperCase", datosToUpperCase);
                        sendResponse(response);
                        break;

                    case "toUpperCase":

                        datos = (String) request.cuerpoGet("datos");
                        String datosToUpperCaseApp = datos.toUpperCase();
                        
                         System.out.println("in datosToUpperCase: " + datosToUpperCaseApp);

                        //responder                        
                        response.cuerpoPut("datosToUpperCase", datosToUpperCaseApp);
                        // responseIntraCC.cuerpoPut("datosToUpperCase", datosToUpperCase);
                        sendResponse(response);
                        break;

                    default:
                        response.encabezadoPut("codigo", 404);
                        response.encabezadoPut("mensaje", "¡404 Not Found! ¡Operación no válida!");
                        sendResponse(response);
                        break;
                }

            } catch (Exception ex) {
                Logger.getLogger(APIIntraCC.class.getName()).log(Level.SEVERE, null, ex);
                response.encabezadoPut("codigo", 500);
                response.encabezadoPut("mensaje", "500 Internal Server Error: " + ex);
                sendResponse(response);
            }

        } catch (IOException ex) {
            Logger.getLogger(APIIntraCC.class.getName()).log(Level.SEVERE, "500 Internal Server Error: mientras se leia/escribia en el socket", ex);
        }
        Logger.getLogger(APIIntraCC.class.getName()).log(Level.INFO, response.toString("", "Response"));
        cerrarSocket();
    }

    private void sendResponse(Response response) throws IOException {
        sendData(gson.toJson(response).getBytes(StandardCharsets.ISO_8859_1));
    }

    private void sendMessageStr(String mensajeStr) throws IOException {
        sendData(mensajeStr.getBytes(StandardCharsets.ISO_8859_1));
    }

    public void sendMetadata(byte[] mensajeBytes) throws IOException {
        int length = mensajeBytes.length;
        bufferedOutputStream.write(length >> 8);
        bufferedOutputStream.write(length);
        bufferedOutputStream.write(mensajeBytes);
        bufferedOutputStream.flush();
        // System.out.println("Mensaje saliente (byte[])\nTamaño del mensaje: " + length + "\nMensaje (String): " + new String(mensajeBytes));
    }

    public void sendData(byte[] data) throws IOException {
        long dataLength = data.length;//* 1L;
        byte[] dataLengthBytes = longToBytes(dataLength);
        bufferedOutputStream.write(dataLengthBytes);
        bufferedOutputStream.write(data);
        bufferedOutputStream.flush();
    }

    private Request receiveRequest() throws IOException {
        return gson.fromJson(new String(receiveData(), StandardCharsets.ISO_8859_1), Request.class);
    }

    private String receiveMessageStr() throws IOException {
        return new String(receiveData(), StandardCharsets.ISO_8859_1);
    }

    private byte[] receiveMetadata() throws IOException {
        int length = (bufferedInputStream.read() << 8) | bufferedInputStream.read();
        byte[] mensajeBytes = new byte[length];
        bufferedInputStream.read(mensajeBytes);
        //System.out.println("Mensaje entrante (byte[])\nTamaño del mensaje: " + length + "\nMensaje (String): " + new String(mensajeBytes, StandardCharsets.ISO_8859_1));
        return mensajeBytes;
    }

    public byte[] receiveData() throws IOException {
        byte[] dataLengthBytes = new byte[8];
        bufferedInputStream.read(dataLengthBytes);
        long dataLength = bytesToLong(dataLengthBytes);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int bytesRead;
        long totalBytesRead = 0;
        while (totalBytesRead < dataLength && (bytesRead = bufferedInputStream.read(buffer)) != -1) {
            baos.write(buffer, 0, bytesRead);
            totalBytesRead += bytesRead;
        }
        byte[] receivedData = baos.toByteArray();
        baos.close();
        baos = null;
        return receivedData;
    }

    private byte[] longToBytes(long value) {
        byte[] result = new byte[8];
        for (int i = 7; i >= 0; i--) {
            result[i] = (byte) (value & 0xFF);
            value >>= 8;
        }
        return result;
    }

    private long bytesToLong(byte[] bytes) {
        long value = 0;
        for (int i = 0; i < 8; i++) {
            value = (value << 8) | (bytes[i] & 0xff);
        }
        return value;
    }

    void cerrarSocket() {
        try {
            if (bufferedInputStream != null) {
                bufferedInputStream.close();
            }
            if (bufferedOutputStream != null) {
                bufferedOutputStream.close();
            }
            if (clientSocket != null && clientSocket.isConnected()) {
                clientSocket.close();
            }
            //Logger.getLogger(APIIntraCC.class.getName()).log(Level.INFO, "Socket cerrado exitosamente : " + time);
        } catch (IOException ex) {
            Logger.getLogger(APIIntraCC.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public String toUpperCase(String id, String datos) {//test

        String datosToUpperCase = "";
        ClienteSocketCC cscc = null;
        Response res;
        Request req;

        req = new Request();
        
        //req.cuerpoPut("tipo", "StartWorkflow");
        req.cuerpoPut("id", id);
        //req.cuerpoPut("op", "toLowerCase");
        req.cuerpoPut("op", "toUpperCase");      
        req.cuerpoPut("datos", datos);
        
        Logger.getLogger(APIIntraCC.class.getName()).log(Level.INFO, request.toString("FROM AppToLowerCase TO AppToUpperCase", "Request"));
        int codigo = -1;
        int c = 0;
        int maxC = 3;
        while (codigo != 200 && c < maxC) {
            c++;
            try {
                cscc = new ClienteSocketCC(Config.Acceso, Config.puerto_intra_cc);
                cscc.sendRequest(req);
                //req.print();
                res = cscc.receiveResponse();
                //res.print();
                Logger.getLogger(APIIntraCC.class.getName()).log(Level.INFO, request.toString("IN ApToLowerCase FROM AppToUpperCase", "Response"));
                codigo = ((Double) res.encabezadoGet("codigo")).intValue();
                if (codigo == 200) {
                    c = maxC;
                    datosToUpperCase = (String) res.cuerpoGet("datosToUpperCase");
                    break;
                }
            } catch (IOException ex) {
                Logger.getLogger(APIIntraCC.class.getName()).log(Level.SEVERE, null, ex);
            }
            cscc.cerrarSocket();
        }

        return datosToUpperCase;
    }

}
