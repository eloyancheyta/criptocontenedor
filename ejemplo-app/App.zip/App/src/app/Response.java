package app;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author eloy_
 */
public class Response {

    private Map<String, Object> encabezado = new HashMap<>();
    private Map<String, Object> cuerpo = new HashMap<>();

    Response() {
        encabezado.put("timestamp", System.currentTimeMillis());
    }

    /**
     * @return the encabezado
     */
    public Map<String, Object> getEncabezado() {
        return encabezado;
    }

    /**
     * @param encabezado the encabezado to set
     */
    public void setEncabezado(Map<String, Object> encabezado) {
        this.encabezado = encabezado;
    }

    /**
     * @param clave, valor the encabezado/header to put
     */
    public Object encabezadoPut(String clave, Object valor) {
        return this.encabezado.put(clave, valor);
    }

    /**
     * @return the valor in the encabezado/header for the clave
     */
    public Object encabezadoGet(String clave) {
        return this.encabezado.get(clave);
    }

    /**
     * @return the cuerpo
     */
    public Map<String, Object> getCuerpo() {
        return cuerpo;
    }

    /**
     * @param cuerpo the cuerpo to set
     */
    public void setCuerpo(Map<String, Object> cuerpo) {
        this.cuerpo = cuerpo;
    }

    /**
     * @param clave, valor the cuerpo/body to put
     */
    public Object cuerpoPut(String clave, Object valor) {
        return this.cuerpo.put(clave, valor);
    }

    /**
     * @return the valor in the cuerpo/body for the clave
     */
    public Object cuerpoGet(String clave) {
        return this.cuerpo.get(clave);
    }

    public void print() {

        //System.out.println("Encabezado:");
        String head = "";
        for (Map.Entry<String, Object> entry : encabezado.entrySet()) {
            //obtener la clave de laprimera lalve/secreto solicitado
            String clave = entry.getKey();
            Object valor = entry.getValue();
            //System.out.println("Clave: " + clave + ", Valor: " + valor);
            head += "Clave: " + clave + ", Valor: " + valor + "\n";
        }
        //imprimir cuerpo

        String body = "";
        for (Map.Entry<String, Object> entry : cuerpo.entrySet()) {
            //obtener la clave de laprimera lalve/secreto solicitado
            String clave = entry.getKey();
            Object valor = entry.getValue();
            //System.out.println("Clave: " + clave + ", Valor: " + valor);
            body += "Clave: " + clave + ", Valor: " + valor + "\n";
        }
        System.out.println("Response\n"
                + "Encabezado:\n" + head
                + "Cuerpo:\n" + body);
    }

    public void print(String msg) {
        String head = "";
        for (Map.Entry<String, Object> entry : encabezado.entrySet()) {
            head += "Clave: " + entry.getKey() + ", Valor: " + entry.getValue() + "\n";
        }
        String body = "";
        for (Map.Entry<String, Object> entry : cuerpo.entrySet()) {
            body += "Clave: " + entry.getKey() + ", Valor: " + entry.getValue() + "\n";
        }
        System.out.println(msg + "\n"
                + "Response\n"
                + "Encabezado:\n" + head
                + "Cuerpo:\n" + body);
    }

    public String toString(String msg, String tipo_request_o_response) {
        String obj = tipo_request_o_response + "\nEncabezado:\n";
        for (Map.Entry<String, Object> entry : encabezado.entrySet()) {
            obj += "Clave: " + entry.getKey() + ", Valor: " + entry.getValue() + "\n";
        }
        obj += "Cuerpo:\n";
        for (Map.Entry<String, Object> entry : cuerpo.entrySet()) {
            obj += "Clave: " + entry.getKey() + ", Valor: " + entry.getValue() + "\n";
        }
        return obj + msg + "\n";
    }

}
