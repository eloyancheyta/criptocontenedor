package app;

import com.google.gson.Gson;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * OUT Requiere aplicar servicios de seguridad (confidencialidad y control
 * deacceos) mediante CP-ABE V KeyPair + TOTP Este programa ejecuta clientes
 * sockets
 *
 * @author eloy_
 */
public class ClienteSocketCC  {
    
    Socket socket;
    BufferedInputStream bufferedInputStream;
    BufferedOutputStream bufferedOutputStream;
    Gson gson;

    public ClienteSocketCC(String ip, int puerto) {
        try {
            socket = new Socket(ip, puerto);
            bufferedInputStream = new BufferedInputStream(socket.getInputStream());
            bufferedOutputStream = new BufferedOutputStream(socket.getOutputStream());
            gson = new Gson();
        } catch (IOException ex) {
            Logger.getLogger(ClienteSocketCC.class.getName()).log(Level.SEVERE, null, ex);
            cerrarSocket(); 
        }
    }

    public void sendRequest(Request request) throws IOException {
        sendData(gson.toJson(request).getBytes(StandardCharsets.ISO_8859_1));
    }

    public void sendMessageStr(String mensajeStr) throws IOException {
        sendData(mensajeStr.getBytes(StandardCharsets.ISO_8859_1));
    }

    public void sendMetadata(byte[] mensajeBytes) throws IOException {
        bufferedOutputStream.write(mensajeBytes.length >> 8);
        bufferedOutputStream.write(mensajeBytes.length);
        bufferedOutputStream.write(mensajeBytes);
        bufferedOutputStream.flush();
        //System.out.println("Mensaje saliente\ntamaño del mensaje: " + mensajeBytes.length + "\nMensaje: " + new String(mensajeBytes));
    }

    public Response receiveResponse() throws IOException {
        return gson.fromJson(new String(receiveData(), StandardCharsets.ISO_8859_1), Response.class);
    }

    public String receiveMessageStr() throws IOException {
        return new String(receiveData(), StandardCharsets.ISO_8859_1);
    }

    public byte[] receiveMetadata() throws IOException {
        int length = (bufferedInputStream.read() << 8) | bufferedInputStream.read();
        byte[] mensajeBytes = new byte[length];
        bufferedInputStream.read(mensajeBytes);
        //System.out.println("Mensaje entrante\ntamaño del mensaje: " + mensajeBytes.length + "\nMensaje: " + new String(mensajeBytes));
        return mensajeBytes;
    }

    public void sendData(byte[] data) throws IOException {
        long dataLength = data.length;//* 1L;
        byte[] dataLengthBytes = longToBytes(dataLength);
        bufferedOutputStream.write(dataLengthBytes);
        bufferedOutputStream.write(data);
        bufferedOutputStream.flush();
    }

    public byte[] receiveData() throws IOException {
        byte[] dataLengthBytes = new byte[8];
        bufferedInputStream.read(dataLengthBytes);
        long dataLength = bytesToLong(dataLengthBytes);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int bytesRead;
        long totalBytesRead = 0;
        while (totalBytesRead < dataLength && (bytesRead = bufferedInputStream.read(buffer)) != -1) {
            baos.write(buffer, 0, bytesRead);
            totalBytesRead += bytesRead;
        }
        byte[] receivedData = baos.toByteArray();
        baos.close();
        baos = null;
        return receivedData;
    }

    private byte[] longToBytes(long value) {
        byte[] result = new byte[8];
        for (int i = 7; i >= 0; i--) {
            result[i] = (byte) (value & 0xFF);
            value >>= 8;
        }
        return result;
    }

    private long bytesToLong(byte[] bytes) {
        long value = 0;
        for (int i = 0; i < 8; i++) {
            value = (value << 8) | (bytes[i] & 0xff);
        }
        return value;
    }

    void cerrarSocket() {
        try {
            if (bufferedInputStream != null) {
                bufferedInputStream.close();
            }
            if (bufferedOutputStream != null) {
                bufferedOutputStream.close();                
            }
            if (socket != null && socket.isConnected()) {
                socket.close();
            }
            //Logger.getLogger(ClienteSocketCC.class.getName()).log(Level.INFO, "Socket cerrado exitosamente");
        } catch (IOException ex) {
            Logger.getLogger(ClienteSocketCC.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
