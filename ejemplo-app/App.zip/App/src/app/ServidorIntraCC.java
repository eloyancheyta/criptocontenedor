package app;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author eloy_
 */
public class ServidorIntraCC extends Thread {

    ServerSocket serverSocket;
    int puerto;

    ServidorIntraCC(int puerto) {
        this.puerto = puerto;
    }

    public void run() {
        while (true) {
            try {
                serverSocket = new ServerSocket(puerto);
                System.out.println("micorservicio " + Config.nombre_microservicio + " del servicio " + Config.nombre_servicio + " iniciado. Esperando conexiones...");

                while (true) {
                    new APIIntraCC(serverSocket.accept()).start();
                }
            } catch (IOException e) {
                Logger.getLogger(ServidorIntraCC.class.getName()).log(Level.SEVERE, Config.nombre_microservicio + " caido", e);
            } finally {
                if (serverSocket != null) {
                    try {
                        serverSocket.close();
                    } catch (IOException e) {
                        Logger.getLogger(ServidorIntraCC.class.getName()).log(Level.SEVERE, Config.nombre_microservicio + " caido", e);
                    }
                }
            }
            System.out.println("El microservicio " + Config.nombre_microservicio + " se restaurará en un momento");
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                Logger.getLogger(ServidorIntraCC.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}