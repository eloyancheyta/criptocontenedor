package app;

/**
 *
 * @author eloy_
 */
public class App {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

       /* Config.nombre_servicio = System.getenv("nombre_servicio");
        //Ruta de la llave insegura para el almacen de llaves y secretos de mapas de servicios
        Config.ruta_keystore_config = System.getenv("ruta_keystore_config");
        Config.ruta_keystore_weak_key = System.getenv("ruta_keystore_key");
        //Ruta de mapas de servicios
        // Config.ruta_mapa_servicio = System.getenv("ruta_mapa_servicio");
        Config.puerto_intra_cc = Integer.parseInt(System.getenv("puerto_intra_cc"));//
        */
        
       
    /*   
        Config.nombre_servicio = System.getenv("nombre_servicio");
        Config.ruta_keystore_config = System.getenv("ruta_keystore_config");
        Config.ruta_keystore_weak_key = System.getenv("ruta_keystore_key");
        Config.puerto_intra_cc = Integer.parseInt(System.getenv("puerto_intra_cc"));
        //App 
        //servidor socket intra-cc escuchando peticiones para llegar a App
        new ServidorIntraCC(Config.puerto_intra_cc).start();
*/
       
       
        
        /*
        FOR testing
        */
       
        Config.Acceso = "localhost";
        Config.puerto_intra_cc = 5000;
        
        //App Cliente
        AppTextoAleatorio appTextoAleatorio = new AppTextoAleatorio();
        appTextoAleatorio.start();
        //appTextoAleatorio.multiWorkers(1,1);

    }
}