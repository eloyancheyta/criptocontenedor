
package app;

/**
 *
 * @author eloy_
 */
public class Config {

    public static String nombre_microservicio = "app";
    public static String nombre_servicio;
    public static String ruta_keystore_config;
    public static String ruta_keystore_weak_key;
    public static int puerto_intra_cc;
    static String Acceso = "acceso";    
}