package app;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author eloy_
 */
public class AppTextoAleatorio {

    AppTextoAleatorio() {
    }

    public void start() {//test
        ClienteSocketCC cscc = null;
        Response res;
        Request req;
        String id = "5ff08b55-d0c2-44e2-a6e9-9af544b77141";
        String datos = generarTexto(100);//App

        req = new Request();
        //req.cuerpoPut("tipo", "StartWorkflow");
        req.cuerpoPut("id", id);
        req.cuerpoPut("op", "toLowerCase");
        //req.cuerpoPut("op", "toUpperCase");      
        req.cuerpoPut("datos", datos);
        
        int codigo = -1;
        int c = 0;
        int maxC = 3;
        while (codigo != 200 && c < maxC) {
            c++;
            try {
                cscc = new ClienteSocketCC(Config.Acceso, Config.puerto_intra_cc);
                cscc.sendRequest(req);
                req.print();
                res = cscc.receiveResponse();
                res.print();
                codigo = ((Double) res.encabezadoGet("codigo")).intValue();
                if (codigo == 200) {
                    c = maxC;
                    break;
                }
            } catch (IOException ex) {
                Logger.getLogger(AppTextoAleatorio.class.getName()).log(Level.SEVERE, null, ex);
            }
            cscc.cerrarSocket();
        }

    }
    
    public void start2() {//test
        ClienteSocketCC clienteSocketIntraCC = null;
        Response responseIntraCC;
        Request request;
        String id = "5ff08b55-d0c2-44e2-a6e9-9af544b77141";
        //crear una petición a acceso para poner datos
        request = new Request();
        request.cuerpoPut("tipo", "StartWorkflow");
        request.cuerpoPut("id", id);
        //   while (true) {
        int c = 0;
        int maxC = 3;
        try {
            try {
                //petición intra cc
                clienteSocketIntraCC = new ClienteSocketCC(Config.Acceso, Config.puerto_intra_cc);
                clienteSocketIntraCC.sendRequest(request);
                request.print();

                responseIntraCC = clienteSocketIntraCC.receiveResponse();
                responseIntraCC.print();
                int codigo = ((Double) responseIntraCC.encabezadoGet("codigo")).intValue();
                if (codigo == 200) {

                    while (c < maxC) {//autorizado
                        c++;
                        // boolean ack = (boolean) response.cuerpoGet("ack");
                        //System.out.println("ack: " + ack);
                        String datos = generarTexto(100);//App
                        request.cuerpoPut("datos", datos);
                        request.print();
                        clienteSocketIntraCC.sendRequest(request);
                        responseIntraCC = clienteSocketIntraCC.receiveResponse();
                        responseIntraCC.print();
                        //si la respuesta es 200 OK continuar
                        codigo = ((Double) responseIntraCC.encabezadoGet("codigo")).intValue();
                        if (codigo == 200) {
                            //esperar un tiempo para una nueva petición
                            Thread.sleep(3000);//solo para testing
                        } else {
                            //no se proceso bien la petición
                            //cerrar sesión
                            clienteSocketIntraCC.cerrarSocket();
                            //  Thread.sleep(3000);//solo para testing
                            break;

                        }
                        //caso contrario salir break;
                        //y reintentar
                    }
                }

                // clienteSocketIntraCC.cerrarSocket();
                /*
                        String datosToLowerCase = (String) responseIntraCC.cuerpoGet("datosToLowerCase");
                        String datosToUppererCase = "";
                        //String datosToUppererCase = (String) responseIntraCC.cuerpoGet("datosToUppereCase");
                        System.out.println("in\ndatosToLowerCase: " + datosToLowerCase
                                + "datosToUppererCase: " + datosToUppererCase);
                 */
 /*  Response response = clienteSocketIntraCC.reciveResponse();
            response.print();
            int codigo = ((Double) response.encabezadoGet("codigo")).intValue();
            if (codigo == 200) {
                boolean ack = (boolean) response.cuerpoGet("ack");
                System.out.println("ack: " + ack);
                //
                //while enviar cargas de trabajo
                //el contenido de las peticiones y respuesta incluye la lógica de extremo a extremo entre app´s (a nivel app de los cc´s)
            }*/
            } catch (IOException ex) {
                Logger.getLogger(App.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
            clienteSocketIntraCC.cerrarSocket();

        } catch (Exception e) {
            Logger.getLogger(App.class
                    .getName()).log(Level.SEVERE, null, e);
            //break;
        }
        //}
    }

    void multiWorkers(int numWorkers, int numberOfTests) {
        for (int i = 0; i < numberOfTests; i++) {

            ArrayList<Thread> ws = new ArrayList();
            for (int w = 0; w < numWorkers; w++) {
                // Crea un nuevo hilo y asigna una tarea que llama al método/tarea
                Thread thread = new Thread(() -> {
                    start();//  appCliente(); // Llama al método 
                });
                // Inicia el hilo
                thread.start();
                ws.add(thread);
                System.out.println("trabajador " + w + " iniciado");
            }

            int m = 0;
            int w = 0;
            while (m < numWorkers) {
                if (ws.get(w).isAlive()) {
                    m++;
                    System.out.println("trabajador " + w + " terminó");
                }
                w++;
            }

            System.out.println("todos los trabajadores han terminado");
        }
    }

    private String generarTexto(int textSize) {
        String caracteresPermitidos = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 ";
        Random rand = new Random();
        StringBuilder textoAleatorio = new StringBuilder();
        for (int i = 0; i < textSize; i++) {
            int indiceAleatorio = rand.nextInt(caracteresPermitidos.length());
            char caracterAleatorio = caracteresPermitidos.charAt(indiceAleatorio);
            textoAleatorio.append(caracterAleatorio);
        }
        System.out.println("Texto Aleatorio: " + textoAleatorio.toString());

        return textoAleatorio.toString();
    }

    private String generarTexto2() {
        // Longitud del texto aleatorio que deseas generar
        int longitud = 100;
        // Caracteres que pueden estar en el texto aleatorio
        String caracteresPermitidos = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 ";
        // Crear una instancia de Random
        Random rand = new Random();
        // Crear una cadena para almacenar el texto aleatorio
        StringBuilder textoAleatorio = new StringBuilder();
        // Generar texto aleatorio
        for (int i = 0; i < longitud; i++) {
            // Generar un índice aleatorio para seleccionar un carácter de la lista de caracteres permitidos
            int indiceAleatorio = rand.nextInt(caracteresPermitidos.length());
            // Obtener el carácter aleatorio y agregarlo al texto aleatorio
            char caracterAleatorio = caracteresPermitidos.charAt(indiceAleatorio);
            textoAleatorio.append(caracterAleatorio);
        }
        // Imprimir el texto aleatorio generado
        System.out.println("Texto Aleatorio: " + textoAleatorio.toString());

        return textoAleatorio.toString();
    }
}
